#include <SFML/Graphics.hpp>
#include <string>
#include <vector>

struct Question {
    std::string prompt;
    std::string answers[4];
    int correctIndex;
};

void updateButtonHover(sf::RectangleShape& button, const sf::Vector2f& mousePos,
    const sf::Color& normalColor, const sf::Color& hoverColor)
{
    if (button.getGlobalBounds().contains(mousePos))
        button.setFillColor(hoverColor);
    else
        button.setFillColor(normalColor);
}

int main()
{
    sf::RenderWindow window(sf::VideoMode({ 900, 650 }), "Jack and Jill Trivia Game");
    sf::Color backgroundColor(30, 30, 60);

    sf::Color blueNormal(70, 130, 180);
    sf::Color blueHover(100, 170, 220);

    sf::Color redNormal(180, 70, 70);
    sf::Color redHover(220, 100, 100);

    sf::Color greenNormal(60, 179, 113);
    sf::Color greenHover(90, 210, 140);

    sf::Color brownNormal(160, 82, 45);
    sf::Color brownHover(190, 110, 70);

    sf::Font font;
    if (!font.openFromFile("C:/Windows/Fonts/arial.ttf"))
    {
        return -1;
    }

    std::vector<Question> staffQuestions = {
        {"1. What grades does Madelaine Halmos Academy serve?",
         {"A. K-5", "B. 6-8", "C. 9-12", "D. Pre-K only"}, 0},

        {"2. Which city is Jack and Jill Center located in?",
         {"A. Miami", "B. Orlando", "C. Fort Lauderdale", "D. Tampa"}, 2},

        {"3. Which of these is one of Jack and Jill Center's main focus areas?",
         {"A. Early education and family support", "B. Airline training", "C. Car sales", "D. Sports management"}, 0},

        {"4. Which department is responsible for school finances?",
         {"A. Athletics", "B. Finance", "C. Cafeteria", "D. Transportation"}, 1},

        {"5. What does VPK stand for?",
         {"A. Very Prepared Kids", "B. Voluntary Prekindergarten", "C. Virtual Parent Knowledge", "D. Verified Primary Kindergarten"}, 1}
    };

    std::vector<Question> funQuestions = {
        {"1. Which system is commonly used for enrollment or school records?",
         {"A. Steam", "B. Netflix", "C. Spotify", "D. Blackbaud"}, 3},

        {"2. Which device type is most commonly used for classroom presentations?",
         {"A. Gaming console", "B. Smart board", "C. Refrigerator", "D. Printer cable only"}, 1},

        {"3. Which season usually feels busiest around school events?",
         {"A. Spring", "B. Winter", "C. Summer", "D. Fall"}, 0},

        {"4. Which office tool is most likely to be used for sending staff messages?",
         {"A. Camera App", "B. Thunderbird", "C. Outlook", "D. Spark Mail"}, 2},

        {"5. Which of these is most important when helping a parent at the front desk?",
         {"A. Patience and professionalism", "B. Guessing quickly", "C. Ignoring the problem", "D. Talking as fast as possible"}, 0}
    };

    enum class Screen {
        Title,
        Category,
        Quiz,
        Result
    };

    enum class QuizType {
        None,
        Staff,
        Fun
    };

    Screen currentScreen = Screen::Title;
    QuizType currentQuizType = QuizType::None;

    std::vector<Question>* currentQuiz = nullptr;
    int currentQuestionIndex = 0;
    int score = 0;
    bool answeredCurrentQuestion = false;

    // ---------- Title Screen ----------
    sf::Text title(font, "Jack and Jill Trivia Game", 40);
    title.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = title.getLocalBounds();
        title.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    title.setPosition(sf::Vector2f(450.f, 120.f));

    sf::RectangleShape startButton(sf::Vector2f(260.f, 85.f));
    startButton.setFillColor(blueNormal);
    startButton.setPosition(sf::Vector2f(320.f, 230.f));

    sf::RectangleShape exitButton(sf::Vector2f(260.f, 85.f));
    exitButton.setFillColor(redNormal);
    exitButton.setPosition(sf::Vector2f(320.f, 350.f));

    sf::Text startText(font, "Start", 30);
    startText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = startText.getLocalBounds();
        startText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    startText.setPosition(sf::Vector2f(450.f, 272.f));

    sf::Text exitText(font, "Exit", 30);
    exitText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = exitText.getLocalBounds();
        exitText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    exitText.setPosition(sf::Vector2f(450.f, 392.f));

    // ---------- Category Screen ----------
    sf::Text categoryTitle(font, "Choose a Quiz Category", 36);
    categoryTitle.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = categoryTitle.getLocalBounds();
        categoryTitle.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    categoryTitle.setPosition(sf::Vector2f(450.f, 100.f));

    sf::RectangleShape staffButton(sf::Vector2f(320.f, 85.f));
    staffButton.setFillColor(blueNormal);
    staffButton.setPosition(sf::Vector2f(290.f, 210.f));

    sf::RectangleShape funButton(sf::Vector2f(320.f, 85.f));
    funButton.setFillColor(greenNormal);
    funButton.setPosition(sf::Vector2f(290.f, 330.f));

    sf::RectangleShape categoryBackButton(sf::Vector2f(200.f, 65.f));
    categoryBackButton.setFillColor(brownNormal);
    categoryBackButton.setPosition(sf::Vector2f(350.f, 470.f));

    sf::Text staffText(font, "Staff Knowledge", 28);
    staffText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = staffText.getLocalBounds();
        staffText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    staffText.setPosition(sf::Vector2f(450.f, 252.f));

    sf::Text funText(font, "Fun Trivia", 28);
    funText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = funText.getLocalBounds();
        funText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    funText.setPosition(sf::Vector2f(450.f, 372.f));

    sf::Text categoryBackText(font, "Back", 26);
    categoryBackText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = categoryBackText.getLocalBounds();
        categoryBackText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    categoryBackText.setPosition(sf::Vector2f(450.f, 502.f));

    // ---------- Quiz Screen ----------
    sf::Text quizTitle(font, "", 32);
    quizTitle.setFillColor(sf::Color::White);
    quizTitle.setPosition(sf::Vector2f(60.f, 40.f));

    sf::Text questionText(font, "", 26);
    questionText.setFillColor(sf::Color::White);
    questionText.setPosition(sf::Vector2f(60.f, 110.f));

    sf::RectangleShape answerButtons[4];
    sf::Text answerTexts[4] = {
        sf::Text(font, "", 22),
        sf::Text(font, "", 22),
        sf::Text(font, "", 22),
        sf::Text(font, "", 22)
    };

    answerButtons[0].setSize(sf::Vector2f(340.f, 70.f));
    answerButtons[1].setSize(sf::Vector2f(340.f, 70.f));
    answerButtons[2].setSize(sf::Vector2f(340.f, 70.f));
    answerButtons[3].setSize(sf::Vector2f(340.f, 70.f));

    answerButtons[0].setPosition(sf::Vector2f(70.f, 220.f));
    answerButtons[1].setPosition(sf::Vector2f(490.f, 220.f));
    answerButtons[2].setPosition(sf::Vector2f(70.f, 330.f));
    answerButtons[3].setPosition(sf::Vector2f(490.f, 330.f));

    for (int i = 0; i < 4; i++) {
        answerButtons[i].setFillColor(blueNormal);
        answerTexts[i].setFillColor(sf::Color::White);
    }

    sf::Text feedbackText(font, "", 24);
    feedbackText.setPosition(sf::Vector2f(60.f, 430.f));

    sf::RectangleShape nextButton(sf::Vector2f(200.f, 60.f));
    nextButton.setFillColor(blueNormal);
    nextButton.setPosition(sf::Vector2f(600.f, 540.f));

    sf::Text nextText(font, "Next", 24);
    nextText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = nextText.getLocalBounds();
        nextText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    nextText.setPosition(sf::Vector2f(700.f, 570.f));

    sf::RectangleShape quizBackButton(sf::Vector2f(200.f, 60.f));
    quizBackButton.setFillColor(brownNormal);
    quizBackButton.setPosition(sf::Vector2f(100.f, 540.f));

    sf::Text quizBackText(font, "Menu", 24);
    quizBackText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = quizBackText.getLocalBounds();
        quizBackText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    quizBackText.setPosition(sf::Vector2f(200.f, 570.f));

    // ---------- Result Screen ----------
    sf::Text resultTitle(font, "Quiz Complete!", 40);
    resultTitle.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = resultTitle.getLocalBounds();
        resultTitle.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    resultTitle.setPosition(sf::Vector2f(450.f, 120.f));

    sf::Text scoreText(font, "", 34);
    scoreText.setFillColor(sf::Color::Yellow);
    scoreText.setPosition(sf::Vector2f(290.f, 230.f));

    sf::Text resultMessage(font, "", 28);
    resultMessage.setFillColor(sf::Color::White);
    resultMessage.setPosition(sf::Vector2f(300.f, 300.f));

    sf::RectangleShape playAgainButton(sf::Vector2f(240.f, 75.f));
    playAgainButton.setFillColor(blueNormal);
    playAgainButton.setPosition(sf::Vector2f(330.f, 400.f));

    sf::Text playAgainText(font, "Play Again", 28);
    playAgainText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = playAgainText.getLocalBounds();
        playAgainText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    playAgainText.setPosition(sf::Vector2f(450.f, 438.f));

    sf::RectangleShape resultMenuButton(sf::Vector2f(240.f, 75.f));
    resultMenuButton.setFillColor(brownNormal);
    resultMenuButton.setPosition(sf::Vector2f(330.f, 500.f));

    sf::Text resultMenuText(font, "Main Menu", 28);
    resultMenuText.setFillColor(sf::Color::White);
    {
        sf::FloatRect b = resultMenuText.getLocalBounds();
        resultMenuText.setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f, b.position.y + b.size.y / 2.f));
    }
    resultMenuText.setPosition(sf::Vector2f(450.f, 538.f));

    auto resetAnswerButtonColors = [&]() {
        for (int i = 0; i < 4; i++) {
            answerButtons[i].setFillColor(blueNormal);
        }
        };

    auto loadQuestion = [&]() {
        resetAnswerButtonColors();
        feedbackText.setString("");

        if (currentQuizType == QuizType::Staff) {
            quizTitle.setString("Staff Knowledge Quiz");
        }
        else {
            quizTitle.setString("Fun Trivia Quiz");
        }

        questionText.setString((*currentQuiz)[currentQuestionIndex].prompt);

        for (int i = 0; i < 4; i++) {
            answerTexts[i].setString((*currentQuiz)[currentQuestionIndex].answers[i]);

            sf::FloatRect b = answerTexts[i].getLocalBounds();
            answerTexts[i].setOrigin(sf::Vector2f(b.position.x + b.size.x / 2.f,
                b.position.y + b.size.y / 2.f));

            sf::Vector2f btnPos = answerButtons[i].getPosition();
            sf::Vector2f btnSize = answerButtons[i].getSize();
            answerTexts[i].setPosition(sf::Vector2f(btnPos.x + btnSize.x / 2.f,
                btnPos.y + btnSize.y / 2.f));
        }

        answeredCurrentQuestion = false;
        };

    auto goToResults = [&]() {
        currentScreen = Screen::Result;
        scoreText.setString("Your Score: " + std::to_string(score) + " out of " + std::to_string(currentQuiz->size()));

        if (score == static_cast<int>(currentQuiz->size())) {
            resultMessage.setString("Excellent job!");
        }
        else if (score >= 4) {
            resultMessage.setString("Great work!");
        }
        else if (score >= 3) {
            resultMessage.setString("Good job!");
        }
        else {
            resultMessage.setString("Keep practicing!");
        }
        };

    while (window.isOpen())
    {
        while (const auto event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
                window.close();

            if (const auto* mousePressed = event->getIf<sf::Event::MouseButtonPressed>())
            {
                if (mousePressed->button == sf::Mouse::Button::Left)
                {
                    sf::Vector2f mousePos(static_cast<float>(mousePressed->position.x),
                        static_cast<float>(mousePressed->position.y));

                    if (currentScreen == Screen::Title)
                    {
                        if (startButton.getGlobalBounds().contains(mousePos)) {
                            currentScreen = Screen::Category;
                        }
                        if (exitButton.getGlobalBounds().contains(mousePos)) {
                            window.close();
                        }
                    }
                    else if (currentScreen == Screen::Category)
                    {
                        if (staffButton.getGlobalBounds().contains(mousePos)) {
                            currentQuizType = QuizType::Staff;
                            currentQuiz = &staffQuestions;
                            currentQuestionIndex = 0;
                            score = 0;
                            currentScreen = Screen::Quiz;
                            loadQuestion();
                        }

                        if (funButton.getGlobalBounds().contains(mousePos)) {
                            currentQuizType = QuizType::Fun;
                            currentQuiz = &funQuestions;
                            currentQuestionIndex = 0;
                            score = 0;
                            currentScreen = Screen::Quiz;
                            loadQuestion();
                        }

                        if (categoryBackButton.getGlobalBounds().contains(mousePos)) {
                            currentScreen = Screen::Title;
                        }
                    }
                    else if (currentScreen == Screen::Quiz)
                    {
                        if (quizBackButton.getGlobalBounds().contains(mousePos)) {
                            currentScreen = Screen::Category;
                        }

                        if (!answeredCurrentQuestion)
                        {
                            for (int i = 0; i < 4; i++) {
                                if (answerButtons[i].getGlobalBounds().contains(mousePos)) {
                                    answeredCurrentQuestion = true;

                                    int correct = (*currentQuiz)[currentQuestionIndex].correctIndex;

                                    if (i == correct) {
                                        answerButtons[i].setFillColor(sf::Color::Green);
                                        feedbackText.setString("Correct!");
                                        feedbackText.setFillColor(sf::Color::Green);
                                        score++;
                                    }
                                    else {
                                        answerButtons[i].setFillColor(sf::Color::Red);
                                        answerButtons[correct].setFillColor(sf::Color::Green);
                                        feedbackText.setString("Wrong! Correct answer: " + (*currentQuiz)[currentQuestionIndex].answers[correct]);
                                        feedbackText.setFillColor(sf::Color::Red);
                                    }
                                }
                            }
                        }

                        if (nextButton.getGlobalBounds().contains(mousePos) && answeredCurrentQuestion)
                        {
                            currentQuestionIndex++;

                            if (currentQuestionIndex < static_cast<int>(currentQuiz->size())) {
                                loadQuestion();
                            }
                            else {
                                goToResults();
                            }
                        }
                    }
                    else if (currentScreen == Screen::Result)
                    {
                        if (playAgainButton.getGlobalBounds().contains(mousePos)) {
                            currentQuestionIndex = 0;
                            score = 0;
                            currentScreen = Screen::Quiz;
                            loadQuestion();
                        }

                        if (resultMenuButton.getGlobalBounds().contains(mousePos)) {
                            currentScreen = Screen::Title;
                            currentQuizType = QuizType::None;
                            currentQuiz = nullptr;
                        }
                    }
                }
            }
        }

        sf::Vector2f mousePos = window.mapPixelToCoords(sf::Mouse::getPosition(window));

        if (currentScreen == Screen::Title)
        {
            updateButtonHover(startButton, mousePos, blueNormal, blueHover);
            updateButtonHover(exitButton, mousePos, redNormal, redHover);
        }
        else if (currentScreen == Screen::Category)
        {
            updateButtonHover(staffButton, mousePos, blueNormal, blueHover);
            updateButtonHover(funButton, mousePos, greenNormal, greenHover);
            updateButtonHover(categoryBackButton, mousePos, brownNormal, brownHover);
        }
        else if (currentScreen == Screen::Quiz)
        {
            if (!answeredCurrentQuestion)
            {
                updateButtonHover(answerButtons[0], mousePos, blueNormal, blueHover);
                updateButtonHover(answerButtons[1], mousePos, blueNormal, blueHover);
                updateButtonHover(answerButtons[2], mousePos, blueNormal, blueHover);
                updateButtonHover(answerButtons[3], mousePos, blueNormal, blueHover);
            }

            updateButtonHover(quizBackButton, mousePos, brownNormal, brownHover);
            updateButtonHover(nextButton, mousePos, blueNormal, blueHover);
        }
        else if (currentScreen == Screen::Result)
        {
            updateButtonHover(playAgainButton, mousePos, blueNormal, blueHover);
            updateButtonHover(resultMenuButton, mousePos, brownNormal, brownHover);
        }

        window.clear(backgroundColor);

        if (currentScreen == Screen::Title)
        {
            window.draw(title);
            window.draw(startButton);
            window.draw(exitButton);
            window.draw(startText);
            window.draw(exitText);
        }
        else if (currentScreen == Screen::Category)
        {
            window.draw(categoryTitle);
            window.draw(staffButton);
            window.draw(funButton);
            window.draw(categoryBackButton);
            window.draw(staffText);
            window.draw(funText);
            window.draw(categoryBackText);
        }
        else if (currentScreen == Screen::Quiz)
        {
            window.draw(quizTitle);
            window.draw(questionText);

            for (int i = 0; i < 4; i++) {
                window.draw(answerButtons[i]);
                window.draw(answerTexts[i]);
            }

            window.draw(quizBackButton);
            window.draw(quizBackText);
            window.draw(nextButton);
            window.draw(nextText);

            if (!feedbackText.getString().isEmpty()) {
                window.draw(feedbackText);
            }
        }
        else if (currentScreen == Screen::Result)
        {
            window.draw(resultTitle);
            window.draw(scoreText);
            window.draw(resultMessage);
            window.draw(playAgainButton);
            window.draw(playAgainText);
            window.draw(resultMenuButton);
            window.draw(resultMenuText);
        }

        window.display();
    }

    return 0;
}